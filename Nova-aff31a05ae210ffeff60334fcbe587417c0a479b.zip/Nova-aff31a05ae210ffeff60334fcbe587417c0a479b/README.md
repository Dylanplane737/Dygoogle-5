# Nova – Smart Web Launcher  

A fun little web app i made.  
Search websites, get instant Wikipedia summaries, related images & videos, dictionary definitions…  
who knows you may even get rickrolled. 

---

## 🎮 Search Now  

 [**Click here to use Nova in your browser**](https://dylanplane737.github.io/Nova/)  

_No downloads needed — works directly online with GitHub Pages._  

---

## 💻 Run Locally  

If you’d rather download it:  
1. Click the green **Code** button on this page.  
2. Choose **Download ZIP**.  
3. Unzip, then open `index.html` in your browser.  

---
## 📜 License  

No license (all rights reserved) — feel free to play, but please don’t redistribute without permission.  
